const goalInput = document.getElementById('goalInput');
const setGoalBtn = document.getElementById('setGoalBtn');
const drinkBtn = document.getElementById('drinkBtn');
const progressFill = document.getElementById('progressFill');
const progressText = document.getElementById('progressText');
const message = document.getElementById('message');

let goal = 0;
let current = 0;

function saveData() {
  const data = { goal: goal, current: current };
  localStorage.setItem('waterData', JSON.stringify(data));
}

function loadData() {
  const saved = JSON.parse(localStorage.getItem('waterData'));
  if (saved) {
    goal = saved.goal;
    current = saved.current;
    progressText.textContent = current + ' / ' + goal + ' glasses';
    const percent = goal > 0 ? (current / goal) * 100 : 0;
    progressFill.style.width = percent + '%';
  }
}

setGoalBtn.addEventListener('click', function() {
  goal = parseInt(goalInput.value);
  current = 0;
  progressText.textContent = current + ' / ' + goal + ' glasses';
  saveData();
});

drinkBtn.addEventListener('click', function() {
  if (goal === 0) {
    return;
  }
  current = current + 1;
  progressText.textContent = current + ' / ' + goal + ' glasses';
  const percent = (current / goal) * 100;
  progressFill.style.width = percent + '%';
  if (current >= goal) {
    message.textContent = '🎉 Congrats! You hit your goal!';
  }
  saveData();
});

loadData();

